﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace Grunderna_i_OOP
{
    internal class Circle
    {
        public double Radie { get; set; }
        public double Area { get; private set; }
        
        public Circle(double radie)
        {
            Radie = radie;
            GetArea();
        }

        public double GetArea()
        {
            Area = Radie * Radie * Math.PI; 
            return Area;
        }   
    }
}
