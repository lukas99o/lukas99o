﻿namespace Grunderna_i_OOP
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Circle myCircle1 = new Circle(5);
            double area1 = myCircle1.Area;
            Circle myCircle2 = new Circle(6);
            double area2 = myCircle2.Area;

            Console.WriteLine($"Radius: {myCircle1.Radie}");
            Console.WriteLine($"Area: {area1}");
            Console.WriteLine();
            Console.WriteLine($"Radius: {myCircle2.Radie}");
            Console.WriteLine($"Area: {area2}");
            Console.WriteLine();
            Console.Write("Press any key to continue. ");
            Console.ReadKey();
        }
    }
}