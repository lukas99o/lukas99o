﻿using System.Data.SqlTypes;
using System.Reflection.Metadata.Ecma335;
using System.Security.Cryptography.X509Certificates;

namespace NumbersGame
{
    internal class Program
    {
        static int checkGuess(int num)
        {
            num = num - 1;
            return num;
        }
        static void Main(string[] args)
        {
            {
                Random random = new Random();
                int randomNumber = random.Next(1, 20);

                Console.WriteLine();
                Console.WriteLine("Welcome! I am thinking of a number. What number do you think it is? You can have as many tries as you want!");
                Console.Write("How many tries do you want? ");

                int numberOfGuesses = int.Parse(Console.ReadLine());
                Console.WriteLine();
                Console.WriteLine($"Du får {numberOfGuesses} försök!");

                while (numberOfGuesses != 0)
                {
                    Console.Write("Please make a guess! ");

                    int guess = int.Parse(Console.ReadLine());
                    Console.WriteLine();
                        
                    if (guess == randomNumber)
                    {
                        Console.WriteLine("|| Wohoo! You did it! ||");
                        break;
                    }
                    else if (guess < randomNumber)
                    {
                        Console.WriteLine("Sorry, to high!");
                    }
                    else
                    {
                        Console.WriteLine("Sorry, to low!");
                    }

                    numberOfGuesses = checkGuess(numberOfGuesses);
                   if (numberOfGuesses > 0)
                    {
                        Console.WriteLine($"You have {numberOfGuesses} left!");
                    }
                   else
                    {
                        Console.WriteLine("You have no guesses left! GOOD LUCK NEXT TIME!");
                    }
                    
                    Console.WriteLine();
                }             
            }
        }
    }
}